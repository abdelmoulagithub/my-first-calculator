﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button1.Location = New System.Drawing.Point(12, 180)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(112, 58)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "1"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button2.Location = New System.Drawing.Point(248, 180)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(112, 58)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "3"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button3.Location = New System.Drawing.Point(248, 308)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(112, 58)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "9"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button4.Location = New System.Drawing.Point(248, 244)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(112, 58)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "6"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button5.Location = New System.Drawing.Point(130, 372)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(112, 58)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "0"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button6.Location = New System.Drawing.Point(130, 308)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(112, 58)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "8"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button7.Location = New System.Drawing.Point(130, 244)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(112, 58)
        Me.Button7.TabIndex = 6
        Me.Button7.Text = "5"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button8.Location = New System.Drawing.Point(130, 180)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(112, 58)
        Me.Button8.TabIndex = 7
        Me.Button8.Text = "2"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button9.Location = New System.Drawing.Point(12, 244)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(112, 58)
        Me.Button9.TabIndex = 8
        Me.Button9.Text = "4"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button10.Location = New System.Drawing.Point(12, 372)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(112, 58)
        Me.Button10.TabIndex = 9
        Me.Button10.Text = "C"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button11.Location = New System.Drawing.Point(12, 308)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(112, 58)
        Me.Button11.TabIndex = 10
        Me.Button11.Text = "7"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button12.Location = New System.Drawing.Point(248, 372)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(112, 58)
        Me.Button12.TabIndex = 11
        Me.Button12.Text = "."
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button13.Location = New System.Drawing.Point(130, 436)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(62, 58)
        Me.Button13.TabIndex = 12
        Me.Button13.Text = "+"
        Me.Button13.UseVisualStyleBackColor = False
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button14.Location = New System.Drawing.Point(187, 436)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(55, 58)
        Me.Button14.TabIndex = 13
        Me.Button14.Text = "-"
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button15.Location = New System.Drawing.Point(248, 436)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(58, 58)
        Me.Button15.TabIndex = 14
        Me.Button15.Text = "x"
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button16
        '
        Me.Button16.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button16.Location = New System.Drawing.Point(303, 436)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(57, 58)
        Me.Button16.TabIndex = 15
        Me.Button16.Text = "/"
        Me.Button16.UseVisualStyleBackColor = False
        '
        'Button18
        '
        Me.Button18.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button18.Location = New System.Drawing.Point(366, 244)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(60, 58)
        Me.Button18.TabIndex = 17
        Me.Button18.Text = "exp"
        Me.Button18.UseVisualStyleBackColor = False
        '
        'Button19
        '
        Me.Button19.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button19.Location = New System.Drawing.Point(366, 180)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(60, 58)
        Me.Button19.TabIndex = 18
        Me.Button19.Text = "mod"
        Me.Button19.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(12, 47)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(414, 95)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = " 0"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label2.Location = New System.Drawing.Point(31, 58)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(16, 24)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = " "
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(55, 29)
        Me.ExitToolStripMenuItem.Text = "exit"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(439, 33)
        Me.MenuStrip1.TabIndex = 21
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Button20
        '
        Me.Button20.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button20.Location = New System.Drawing.Point(12, 436)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(112, 56)
        Me.Button20.TabIndex = 22
        Me.Button20.Text = "="
        Me.Button20.UseVisualStyleBackColor = False
        '
        'Button17
        '
        Me.Button17.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button17.Location = New System.Drawing.Point(366, 308)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(60, 58)
        Me.Button17.TabIndex = 23
        Me.Button17.Text = "sin"
        Me.Button17.UseVisualStyleBackColor = False
        '
        'Button21
        '
        Me.Button21.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button21.Location = New System.Drawing.Point(366, 372)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(60, 58)
        Me.Button21.TabIndex = 24
        Me.Button21.Text = "cos"
        Me.Button21.UseVisualStyleBackColor = False
        '
        'Button22
        '
        Me.Button22.BackColor = System.Drawing.Color.LightSlateGray
        Me.Button22.Location = New System.Drawing.Point(366, 436)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(60, 58)
        Me.Button22.TabIndex = 25
        Me.Button22.Text = "tan"
        Me.Button22.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(439, 510)
        Me.Controls.Add(Me.Button22)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.Button20)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button19)
        Me.Controls.Add(Me.Button18)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "CALCULATOR"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents Button20 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Button22 As Button
End Class
