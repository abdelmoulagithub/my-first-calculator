﻿Public Class Form1
    Dim f As Double
    Dim s As Double
    Dim a As Double
    Dim op As String
    Dim n As Int64
    Private Sub Button_Click(sender As Object, e As EventArgs) Handles Button1.Click, Button9.Click, Button8.Click, Button7.Click, Button6.Click, Button5.Click, Button4.Click, Button3.Click, Button2.Click, Button12.Click, Button11.Click
        Dim b As Button = sender
        If Label1.Text = "0" Then
            Label1.Text = CInt(b.Text)
        Else
            Label1.Text = Label1.Text + b.Text
        End If
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Label1.Text = "0"
        Label2.Text = ""
    End Sub

    Private Sub arithmetic_fonctions(sender As Object, e As EventArgs) Handles Button13.Click, Button19.Click, Button18.Click, Button16.Click, Button15.Click, Button14.Click
        Dim ops As Button = sender
        f = Label1.Text
        Label2.Text = Label1.Text
        Label1.Text = " "
        op = ops.Text
        Label2.Text = Label2.Text + " " + op

    End Sub

    Private Sub Button20_Click(sender As Object, e As EventArgs) Handles Button20.Click
        s = Label1.Text
        If op = "+" Then
            a = f + s
            Label1.Text = a
            Label2.Text = " "
        ElseIf op = "-" Then
            a = f - s
            Label1.Text = a
            Label2.Text = " "
        ElseIf op = "x" Then
            a = f * s
            Label1.Text = a
            Label2.Text = " "
        ElseIf op = "/" Then
            a = f / s
            Label1.Text = a
            Label2.Text = " "
        ElseIf op = "mod" Then
            a = f Mod s
            Label1.Text = a
            Label2.Text = " "
        ElseIf op = "exp" Then
            a = f ^ s
            Label1.Text = a
            Label2.Text = " "
        End If

    End Sub
    Private Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click
        f = Label1.Text
        Label1.Text = " "
        f = f * Math.PI / 100
        a = Math.Sin(f)
        Label1.Text = a
        Label2.Text = " "
    End Sub
    Private Sub Button21_Click(sender As Object, e As EventArgs) Handles Button21.Click
        f = Label1.Text
        Label1.Text = " "
        f = f * Math.PI / 100
        a = Math.Cos(f)
        Label1.Text = a
        Label2.Text = " "
    End Sub
    Private Sub Button22_Click(sender As Object, e As EventArgs) Handles Button22.Click
        f = Label1.Text
        Label1.Text = " "
        f = f * Math.PI / 100
        a = Math.Tan(f)
        Label1.Text = a
        Label2.Text = " "
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        End
    End Sub
End Class
